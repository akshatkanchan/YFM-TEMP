export interface User {
    id?:string;
    name?:string;
    userName?:string;
    email?:string;
    permissionsId?:string
    ownerId?:string;
    companyName?:string;
    fileName?:string;
    type?: string;
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allotsupporters',
  templateUrl: './allotsupporters.component.html',
  styleUrls: ['./allotsupporters.component.scss']
})
export class AllotsupportersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

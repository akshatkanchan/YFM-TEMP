import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'viewflightticket',
  templateUrl: './viewflightticket.component.html',
  styleUrls: ['./viewflightticket.component.scss']
})
export class ViewflightticketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
